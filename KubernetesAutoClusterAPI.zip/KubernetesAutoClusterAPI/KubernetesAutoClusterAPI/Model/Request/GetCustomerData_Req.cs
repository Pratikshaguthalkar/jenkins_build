﻿namespace KubernetesAutoClusterAPI.Model.Request
{
    public class GetCustomerData_Req
    {
        public int NoofRecords { get; set; }
    }
}
